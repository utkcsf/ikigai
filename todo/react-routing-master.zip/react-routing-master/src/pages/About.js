import React from "react";

const About = () => {
  return <div style={{fontSize: "3rem", textAlign: "center", margin: "1%"}}>About</div>;
};

export default About;
