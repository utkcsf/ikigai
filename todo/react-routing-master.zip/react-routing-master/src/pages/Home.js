import React from "react";

const Home = () => {
  return <div style={{fontSize: "3rem", textAlign: "center", margin: "1%"}}>Home</div>;
};

export default Home;
